package br.edu.utfpr.coletork.ui.activity

import android.content.DialogInterface
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import br.edu.utfpr.coletork.R
import br.edu.utfpr.coletork.asynctask.BaseAsyncTask
import br.edu.utfpr.coletork.database.AppDatabase
import br.edu.utfpr.coletork.database.dao.PropriedadeDao
import br.edu.utfpr.coletork.model.Propriedade
import br.edu.utfpr.coletork.ui.adapter.recyclerview.ListaPropriedadesAdapter
import kotlinx.android.synthetic.main.activity_visualiza_propriedade.*
import java.text.FieldPosition
import kotlin.math.absoluteValue

private const val TITULO_APPBAR = "Propriedade"
class Activity_Visualiza_Propriedade : AppCompatActivity() {

    private val propriedadeId: Long by lazy {
        intent.getLongExtra("propriedadeId", 0)

    }

    private val posicaoPropriedade: Int by lazy {
        intent.getIntExtra("posicaoPropriedade", 0)

    }

    private lateinit var dao: PropriedadeDao

    private lateinit var propriedade: Propriedade

    private val adapter by lazy {
        ListaPropriedadesAdapter(context = this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualiza_propriedade)
        title = TITULO_APPBAR
        val db: AppDatabase = AppDatabase.getInstance(this)
        dao = db.propriedadeDao;

        Toast.makeText(this, posicaoPropriedade.toString(), Toast.LENGTH_LONG).show()
        //Toast.makeText(this, propriedadeId.toString(), Toast.LENGTH_LONG).show() // coloquei aqui
        //Toast.makeText(this, adapter.posicaoPropriedadeSelecionada.toString(), Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        buscaPropriedadeSelecionada()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.visualiza_propriedade_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.visualiza_propriedade_menu_edita -> abreFormularioEdicao()
            R.id.visualiza_propriedade_menu_remove -> abreDialogConfirmaRemove()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun abreDialogConfirmaRemove() {


        AlertDialog.Builder(this).setTitle("Removendo propriedade")
                .setMessage("Deseja mesmo remover esta propriedade?")
                .setPositiveButton("Sim", DialogInterface.OnClickListener { dialogInterface, _ ->
                    remove(propriedade, posicaoPropriedade)

                })
                .setNegativeButton("Não", null)
                .show()

    }


    private fun abreFormularioEdicao() {
        TODO("Not yet implemented")
    }

    private fun buscaPropriedadeSelecionada() {


        BaseAsyncTask(quandoExecuta = {
            dao.buscaPorId(propriedadeId)
        }, quandoFinaliza = { propriedadeEncontrada ->
            propriedadeEncontrada?.let {
                this.propriedade = it
                preencheCampos(it)

            }
        }).execute()


    }

    private fun preencheCampos(it: Propriedade) {
        activity_visualiza_propriedade_nome.text = propriedade.nome
        activity_visualiza_propriedade_proprietario.text = propriedade.proprietario
        activity_visualiza_propriedade_telefone.text = propriedade.telefone
        activity_visualiza_propriedade_estado.text = propriedade.estado
        activity_visualiza_propriedade_cidade.text = propriedade.cidade
    }

    private fun remove(propriedade: Propriedade, posicao: Int) {
        BaseAsyncTask(
                quandoExecuta = {

                    dao.remove(propriedade)

                }, quandoFinaliza = {
                 adapter.remove(posicao)
        }
        ).execute()



    }
}