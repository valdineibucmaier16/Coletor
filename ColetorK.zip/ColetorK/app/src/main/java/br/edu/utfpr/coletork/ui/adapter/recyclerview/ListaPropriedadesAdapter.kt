package br.edu.utfpr.coletork.ui.adapter.recyclerview

import android.content.Context
import android.view.*
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import br.edu.utfpr.coletork.R
import br.edu.utfpr.coletork.model.Propriedade
import br.edu.utfpr.coletork.ui.activity.Activity_Visualiza_Propriedade
import kotlinx.android.synthetic.main.activity_lista_propriedades.view.*
import kotlinx.android.synthetic.main.propriedade_item.view.*
import java.util.*

class ListaPropriedadesAdapter(
        private val context: Context,
        private val propriedades: MutableList<Propriedade> = mutableListOf(),
        var quandoItemClicado: (propriedade: Propriedade) -> Unit = {}
        )

    : RecyclerView.Adapter<ListaPropriedadesAdapter.ViewHolder>() {

    var posicaoPropriedadeSelecionada = -1



    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): ViewHolder {
        val viewCriada = LayoutInflater.from(context)
            .inflate(
                    R.layout.propriedade_item,
                    parent, false
            )
        return ViewHolder(viewCriada)
    }

    override fun getItemCount() = propriedades.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val propriedade = propriedades[position]
        holder.vincula(propriedade)

    }

    fun atualiza(propriedades: List<Propriedade>) {
        notifyItemRangeRemoved(0, this.propriedades.size)
        this.propriedades.clear()
        this.propriedades.addAll(propriedades)
        notifyItemRangeInserted(0, this.propriedades.size)
    }

    fun remove(posicao: Int) {
        propriedades.removeAt(posicao)
        notifyItemRemoved(posicao)
    }



//    fun adiciona(propriedade: Propriedade) {
//       propriedades.add(propriedade)
//        //this.propriedades.add(propriedade)
//        //Toast.makeText(context, propriedade.nome +"propriedade adicionada" + propriedade.id, Toast.LENGTH_LONG).show() // coloquei aqui tb
//        //notifyItemInserted(propriedades.lastIndex)
//
//    }

    fun adiciona(propriedade: Propriedade){

        var tamanhoAtual =this.propriedades.size
        Collections.addAll(propriedades, propriedade)
        var tamanhoNovo = this.propriedades.size;
        notifyItemRangeInserted(tamanhoAtual, tamanhoNovo);
    }

    inner class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        private lateinit var propriedade: Propriedade


        init {
            itemView.setOnClickListener {




                            if (::propriedade.isInitialized) {

                               // posicaoPropriedadeSelecionada = adapterPosition
                                //Toast.makeText(context, posicaoPropriedadeSelecionada.toString(), Toast.LENGTH_LONG).show()
                                //Toast.makeText(context,"fui selecionado", Toast.LENGTH_LONG).show()
                                    posicaoPropriedadeSelecionada = adapterPosition
                                    quandoItemClicado(propriedade)
                                //posicaoPropriedadeSelecionada = adapterPosition


                }

//                propriedade = propriedades[posicaoPropriedadeSelecionada]
//            Toast.makeText(context,"fui selecionado", Toast.LENGTH_LONG).show()
            }


//            itemView.setOnCreateContextMenuListener { menu, _, _ ->
//                menu.add(Menu.NONE, 1, Menu.NONE, "Remover")
//
//            }



        }

        fun vincula(propriedade: Propriedade) {
            this.propriedade = propriedade
            itemView.propriedade_item_nome.text =propriedade.nome;
            itemView.propriedade_item_proprietario.text = propriedade.proprietario;

        }





    }

    fun getItemPropriedade(position: Int): Propriedade{
        return propriedades[position]
    }










}