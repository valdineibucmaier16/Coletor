package br.edu.utfpr.coletork.database.dao

import androidx.room.*
import br.edu.utfpr.coletork.model.Propriedade

@Dao
interface PropriedadeDao {

        @Query("SELECT * FROM Propriedade ORDER BY id ASC")
        fun buscaTodos(): List<Propriedade>

        @Insert(onConflict = OnConflictStrategy.REPLACE) //onConflictStrategy deve funcionar como update
        fun salva(propriedade: Propriedade)

        @Delete
        fun remove(propriedade: Propriedade)

        @Query("SELECT * FROM Propriedade WHERE id = :id")
        fun buscaPorId(id: Long): Propriedade?

        @Insert(onConflict = OnConflictStrategy.REPLACE)
        fun salva(propriedades: List<Propriedade>)

        @Update
        fun atualiza(propriedade: Propriedade);

        @Query("SELECT id FROM Propriedade ORDER BY ID DESC LIMIT 1")
        fun buscaIdUltimaPropriedade(): Long


}