package br.edu.utfpr.coletork.ui.dialog

import android.content.Context
import android.view.ViewGroup

class EditaPropriedadeDialog(viewGroup: ViewGroup,
                             context: Context) : FormularioPropriedadeDialog(context, viewGroup) {
    override val tituloBotaoPositivo: String
        get() = "Editar"
    override val tituloDialog: String
        get() = "Editando propriedade"

}